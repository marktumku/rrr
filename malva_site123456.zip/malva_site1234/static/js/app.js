const toggle=document.querySelector('.menu-toggle');const mobile=document.querySelector('#mobileNav');
if(toggle&&mobile){toggle.addEventListener('click',()=>{mobile.classList.toggle('open');toggle.textContent=mobile.classList.contains('open')?'×':'☰'})}
const cards=document.querySelectorAll('.product-card');cards.forEach((card,i)=>{card.style.setProperty('--delay',`${Math.min(i*45,360)}ms`);card.classList.add('reveal')});
const orderType=document.querySelectorAll('input[name="order_type"], select[name="order_type"]');const address=document.querySelector('#id_address');
function syncAddress(){const val=[...orderType].find(x=>x.checked)?.value||orderType[0]?.value;if(address){address.closest('.field')?.classList.toggle('disabled-field',val==='pickup');address.disabled=val==='pickup';if(val==='pickup')address.value=''}}
orderType.forEach(x=>x.addEventListener('change',syncAddress));syncAddress();
