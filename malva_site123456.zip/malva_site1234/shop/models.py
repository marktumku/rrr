from django.db import models
from django.urls import reverse

class Category(models.Model):
    name=models.CharField('Назва',max_length=100)
    slug=models.SlugField('Slug',max_length=120,unique=True,allow_unicode=True)
    sort_order=models.PositiveIntegerField('Порядок',default=0)
    active=models.BooleanField('Показувати',default=True)
    class Meta: ordering=['sort_order','name']; verbose_name='Категорія'; verbose_name_plural='Категорії'
    def __str__(self): return self.name

class Product(models.Model):
    category=models.ForeignKey(Category,on_delete=models.CASCADE,related_name='products',verbose_name='Категорія')
    name=models.CharField('Назва',max_length=180)
    slug=models.SlugField('Slug',max_length=200,unique=True,allow_unicode=True)
    description=models.TextField('Опис',blank=True)
    weight=models.CharField('Вага / обʼєм',max_length=60,blank=True)
    price=models.DecimalField('Ціна, грн',max_digits=10,decimal_places=2)
    image=models.ImageField('Фото',upload_to='products/',blank=True)
    available=models.BooleanField('В наявності',default=True)
    sort_order=models.PositiveIntegerField('Порядок',default=0)
    class Meta: ordering=['sort_order','name']; verbose_name='Товар'; verbose_name_plural='Товари'
    def __str__(self): return self.name
    def get_absolute_url(self): return reverse('product',args=[self.slug])

class Order(models.Model):
    TYPE_CHOICES=[('delivery','Доставка'),('pickup','Самовивіз')]
    STATUS_CHOICES=[('new','Нове'),('confirmed','Підтверджено'),('cooking','Готується'),('ready','Готово'),('courier','Курʼєр у дорозі'),('done','Виконано'),('cancelled','Скасовано')]
    customer_name=models.CharField('Імʼя',max_length=120)
    phone=models.CharField('Телефон',max_length=40)
    order_type=models.CharField('Тип',max_length=20,choices=TYPE_CHOICES,default='delivery')
    address=models.CharField('Адреса доставки',max_length=255,blank=True)
    scheduled_for=models.DateTimeField('На час',null=True,blank=True)
    comment=models.TextField('Коментар',blank=True)
    status=models.CharField('Статус',max_length=20,choices=STATUS_CHOICES,default='new')
    total=models.DecimalField('Сума',max_digits=10,decimal_places=2,default=0)
    created_at=models.DateTimeField('Створено',auto_now_add=True)
    class Meta: ordering=['-created_at']; verbose_name='Замовлення'; verbose_name_plural='Замовлення'
    def __str__(self): return f'#{self.pk} — {self.customer_name}'

class OrderItem(models.Model):
    order=models.ForeignKey(Order,on_delete=models.CASCADE,related_name='items')
    product=models.ForeignKey(Product,on_delete=models.PROTECT,verbose_name='Товар')
    quantity=models.PositiveIntegerField('Кількість',default=1)
    price=models.DecimalField('Ціна на момент замовлення',max_digits=10,decimal_places=2)
    def subtotal(self): return self.price*self.quantity
    def __str__(self): return f'{self.product.name} × {self.quantity}'

class Review(models.Model):
    name=models.CharField('Імʼя',max_length=100)
    rating=models.PositiveSmallIntegerField('Оцінка',choices=[(i,str(i)) for i in range(1,6)])
    text=models.TextField('Відгук')
    approved=models.BooleanField('Опубліковано',default=False)
    created_at=models.DateTimeField('Дата',auto_now_add=True)
    class Meta: ordering=['-created_at']; verbose_name='Відгук'; verbose_name_plural='Відгуки'
