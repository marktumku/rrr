from django.contrib import admin
from .models import Category,Product,Order,OrderItem,Review
admin.site.site_header='Мальва — керування сайтом'
admin.site.site_title='Мальва'
admin.site.index_title='Замовлення, меню та відгуки'
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin): list_display=('name','active','sort_order'); prepopulated_fields={'slug':('name',)}
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin): list_display=('name','category','price','weight','available'); list_filter=('category','available'); search_fields=('name','description'); prepopulated_fields={'slug':('name',)}
class OrderItemInline(admin.TabularInline): model=OrderItem; extra=0; readonly_fields=('price',)
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin): list_display=('id','customer_name','phone','order_type','total','status','created_at'); list_filter=('status','order_type','created_at'); search_fields=('customer_name','phone','address'); inlines=[OrderItemInline]; readonly_fields=('total','created_at')
@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display=('name','rating','approved','created_at')
    list_filter=('approved','rating')
    actions=['approve_reviews']
    @admin.action(description='Опублікувати вибрані відгуки')
    def approve_reviews(self,request,queryset): queryset.update(approved=True)
