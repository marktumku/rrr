from decimal import Decimal
from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404,redirect,render
from .forms import CheckoutForm,ReviewForm
from .models import Category,Product,Order,OrderItem,Review

PHONE='+380372513187'
def cart_data(request):
    raw=request.session.get('cart',{})
    items=[]; total=Decimal('0')
    for sid,qty in raw.items():
        p=Product.objects.filter(pk=sid,available=True).first()
        if not p: continue
        sub=p.price*qty; total+=sub; items.append((p,qty,sub))
    return items,total

def home(request):
    return render(request,'shop/home.html',{'categories':Category.objects.filter(active=True),'reviews':Review.objects.filter(approved=True)[:6],'phone':PHONE})
def menu(request): return render(request,'shop/menu.html',{'categories':Category.objects.filter(active=True),'phone':PHONE})
def product(request,slug): return render(request,'shop/product.html',{'product':get_object_or_404(Product,slug=slug,available=True),'phone':PHONE})
def cart_add(request,pk):
    get_object_or_404(Product,pk=pk,available=True); cart=request.session.get('cart',{}); key=str(pk); cart[key]=cart.get(key,0)+1; request.session['cart']=cart; return redirect(request.META.get('HTTP_REFERER','menu'))
def cart_remove(request,pk):
    cart=request.session.get('cart',{}); key=str(pk)
    if key in cart:
        cart[key]-=1
        if cart[key]<=0: del cart[key]
    request.session['cart']=cart; return redirect('cart')
def cart(request):
    items,total=cart_data(request); return render(request,'shop/cart.html',{'items':items,'total':total,'phone':PHONE})
@transaction.atomic
def checkout(request):
    items,total=cart_data(request)
    if not items: return redirect('menu')
    if request.method=='POST':
        form=CheckoutForm(request.POST)
        if form.is_valid():
            order=form.save(commit=False); order.total=total; order.save()
            for p,q,sub in items: OrderItem.objects.create(order=order,product=p,quantity=q,price=p.price)
            request.session['cart']={}; return redirect('order_success',order.pk)
    else: form=CheckoutForm()
    return render(request,'shop/checkout.html',{'form':form,'items':items,'total':total,'phone':PHONE})
def order_success(request,pk): return render(request,'shop/success.html',{'order':get_object_or_404(Order,pk=pk),'phone':PHONE})
def about(request): return render(request,'shop/about.html',{'phone':PHONE})
def reviews(request): return render(request,'shop/reviews.html',{'reviews':Review.objects.filter(approved=True),'form':ReviewForm(),'phone':PHONE})
def add_review(request):
    if request.method=='POST':
        form=ReviewForm(request.POST)
        if form.is_valid(): form.save(); messages.success(request,'Дякуємо! Відгук надіслано на модерацію.'); return redirect('reviews')
    return redirect('reviews')
