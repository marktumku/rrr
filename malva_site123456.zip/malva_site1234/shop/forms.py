from django import forms
from .models import Order,Review
class CheckoutForm(forms.ModelForm):
    scheduled_for=forms.DateTimeField(required=False,input_formats=['%Y-%m-%dT%H:%M'],widget=forms.DateTimeInput(attrs={'type':'datetime-local'}))
    class Meta:
        model=Order
        fields=['customer_name','phone','order_type','address','scheduled_for','comment']
        widgets={'comment':forms.Textarea(attrs={'rows':3,'placeholder':'Коментар до замовлення'}),'address':forms.TextInput(attrs={'placeholder':'Вулиця, будинок, квартира'}),'phone':forms.TextInput(attrs={'placeholder':'+380...'})}
    def clean(self):
        data=super().clean()
        if data.get('order_type')=='delivery' and not data.get('address'): self.add_error('address','Для доставки вкажіть адресу.')
        if data.get('order_type')=='pickup': data['address']=''
        return data
class ReviewForm(forms.ModelForm):
    class Meta: model=Review; fields=['name','rating','text']; widgets={'text':forms.Textarea(attrs={'rows':4})}
